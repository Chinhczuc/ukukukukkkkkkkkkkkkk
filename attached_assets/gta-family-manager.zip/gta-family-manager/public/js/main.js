// JavaScript chính
document.addEventListener('DOMContentLoaded', () => { console.log('Ready'); });