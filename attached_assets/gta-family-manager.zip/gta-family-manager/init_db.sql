-- Tạo bảng thành viên (users)
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    phone TEXT,
    discord_id TEXT,
    age INTEGER,
    bio TEXT,
    reason TEXT,
    clan_id INTEGER,
    avatar TEXT,
    role TEXT DEFAULT 'member',
    status TEXT DEFAULT 'pending',
    score INTEGER DEFAULT 0
);

-- Tạo bảng gia tộc (clans)
CREATE TABLE IF NOT EXISTS clans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    description TEXT,
    banner TEXT,
    owner_id INTEGER
);

-- Tạo bảng đơn xin gia nhập (join_requests)
CREATE TABLE IF NOT EXISTS join_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    clan_id INTEGER,
    status TEXT DEFAULT 'pending',
    message TEXT
);

-- Tạo bảng thông báo (announcements)
CREATE TABLE IF NOT EXISTS announcements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    clan_id INTEGER,
    content TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);