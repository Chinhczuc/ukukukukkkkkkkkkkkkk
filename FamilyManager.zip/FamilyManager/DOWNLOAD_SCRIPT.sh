#!/bin/bash

# Script tạo project GTA Family Manager
echo "Tạo thư mục project..."
mkdir -p gta-family-manager
cd gta-family-manager

# Tạo cấu trúc thư mục
mkdir -p client/src/{components,pages,hooks,lib,types}
mkdir -p client/src/components/{ui,layout,cards,modals}
mkdir -p server
mkdir -p shared

echo "Đã tạo cấu trúc thư mục. Bây giờ copy các file từ Replit:"
echo ""
echo "1. Copy package.json"
echo "2. Copy tsconfig.json"
echo "3. Copy vite.config.ts"
echo "4. Copy tailwind.config.ts"
echo "5. Copy postcss.config.js"
echo "6. Copy components.json"
echo "7. Copy drizzle.config.ts"
echo "8. Copy toàn bộ thư mục client/"
echo "9. Copy toàn bộ thư mục server/"
echo "10. Copy toàn bộ thư mục shared/"
echo ""
echo "Sau khi copy xong, chạy:"
echo "npm install"
echo "npm run dev"